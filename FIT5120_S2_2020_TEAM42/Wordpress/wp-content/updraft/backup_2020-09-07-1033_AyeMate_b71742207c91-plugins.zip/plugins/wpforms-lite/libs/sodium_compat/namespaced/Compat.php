<?php
namespace ParagonIE\Sodium;

class Compat extends \ParagonIE_Sodium_Compat
{

}
